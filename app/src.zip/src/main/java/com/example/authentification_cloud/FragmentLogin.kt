package com.example.authentification_cloud

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.navigation.fragment.findNavController
import com.example.authentification_cloud.databinding.FragmentLoginBinding

class FragmentLogin : Fragment() {

    private lateinit var binding: FragmentLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        // return inflater.inflate(R.layout.fragment_login, container, false)
        binding = FragmentLoginBinding.inflate(layoutInflater)
        val view = binding.root
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.Connectionbutton.setOnClickListener {
            login(binding.ConnectionEmailadd.text.toString(),binding.ConnectionMdpadd.text.toString())
        }
        // handle backPressed
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner,object:
            OnBackPressedCallback(true){
            override fun handleOnBackPressed() {
                findNavController().popBackStack(R.id.fragment_ListPark , false)
            }

        })


    }

    private fun login(username: String, password: String) {
        if(username=="test@gmail.com" && password =="test") {
            saveUserID(requireActivity(),12)
            findNavController().popBackStack()
            requireActivity().invalidateOptionsMenu()
        }
        else {
            Toast.makeText(requireActivity(),"Email ou Mot de passe erroné", Toast.LENGTH_LONG).show()
        }
    }
}

/*
class MainActivity : AppCompatActivity() {

    @SuppressLint("CommitPrefEdits")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pref = getSharedPreferences("Auth", Context.MODE_PRIVATE)
        val connected = pref.getBoolean("connected", false)
        if (connected){
            val intent = Intent(this, MainActivity2::class.java)
            startActivity(intent)
            finish()
        }else{
            setContentView(R.layout.activity_main)
            button2.setOnClickListener {
                if (editText.text.toString() == "test@gmail.com" && editText2.text.toString() == "test"){
                    pref.edit().putBoolean("connected", true).apply()
                    val intent = Intent(this, MainActivity2::class.java)
                    startActivity(intent)
                    finish()
                }else{
                    Toast.makeText(this, "email et/ou mot de passe incorrect(s)", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}

* */