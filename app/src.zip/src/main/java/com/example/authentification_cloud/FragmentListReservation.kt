package com.example.authentification_cloud

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.example.authentification_cloud.databinding.FragmentListReservationBinding

class FragmentListReservation : Fragment() {
    
    private lateinit var binding : FragmentListReservationBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment__list_reservation, container, false)
        binding = FragmentListReservationBinding.inflate(layoutInflater)
        val view = binding.root
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if(isLogin(requireActivity())) {
            binding.TextView2.visibility = View.VISIBLE
        }
        else {
            findNavController().navigate(R.id.action_fragment_ListReservation_to_fragment_login)
        }
    }
}

/*
class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        val pref = getSharedPreferences("Auth", Context.MODE_PRIVATE)
        button8.setOnClickListener {
            pref.edit().putBoolean("connected", false).apply()
            val intent = Intent(this, MainActivity3::class.java)
            startActivity(intent)
            finish()
        }
    }
}
 */