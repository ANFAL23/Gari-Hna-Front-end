package com.example.authentification_cloud

data class User(
    val userID: Int,
    val userName: String,
    val password: String,
)
