package com.example.authentification_cloud

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import androidx.navigation.NavController
import androidx.navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.NavigationUI
import com.example.authentification_cloud.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var navController: NavController
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_main)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        val navFragment = supportFragmentManager.findFragmentById(R.id.navHost) as NavHostFragment
        navController = navFragment.navController
        NavigationUI.setupWithNavController(binding.navBottom,navController)
    }

    override fun onSupportNavigateUp() = navController.navigateUp() || super.onSupportNavigateUp()

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.logout_menu, menu)

        if(isLogin(this)) {
            menu?.getItem(0)?.setVisible(true)
        }
        else {
            menu?.getItem(0)?.setVisible(false)
        }

        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.logout-> {
                clearUserId(this)
                findNavController(R.id.navHost).navigate(R.id.fragment_ListPark)
                invalidateOptionsMenu()
            }
        }
        return  true
    }

}